# -*- coding: utf-8 -*-
# import os
# print(os.getcwd())
def multi_open(file_name):
    import os
    abs_path = os.path.abspath(file_name)
    leaves = os.listdir(abs_path)
    
    for leaf in leaves:
        content = os.path.join(abs_path, leaf)
        content = open(content, 'r')
        # print(content.readlines())
        # print(list(content.read()))
        contents = content.read().splitlines()
        content.close()
        return contents
# Content = multi_open('docs')
# print(type(Content))

# for item in Content:
#     print(item)
    # item.replace('\n','')
    # print(Content)
    
def Count_Word_from_List(List):
    
    English_Words_Dict = ['a', 'b', 'c', 'd', 'e', 'f', 
                          'g', 'h', 'i', 'j', 'k', 'l', 
                          'm', 'n', 'o', 'p', 'q', 'r', 
                          's', 't', 'u', 'v', 'w', 'x', 
                          'y', 'z', '-']

    Words_Processing_Fac = []
    Words_Dict = {}
    for lines in List:
        lines = lines.replace("'m", " am")
        lines = lines.replace("'s", " is")
        lines = lines.replace("'ll", " will")
        lines = lines.replace("'ve", " have")
        lines = lines.replace("'d", " had")
    # String_Para = String_Para.replace('\n', '')
    # String_Para = String_Para.replace("'m", ' am')
    # String_Para = String_Para.replace("'s", ' is')
    # String_Para = String_Para.replace("'ll", ' will')
    # String_Para = String_Para.replace("'ve", ' have')
    #大写转小写
        String_Para = lines.lower()
    
        for i in range(0, len(String_Para)):
            word = String_Para[i: i+1]
            if word in English_Words_Dict:
                Words_Processing_Fac.append(word)

            else:
                if Words_Processing_Fac != []:
                    words = ''
                    for item in Words_Processing_Fac:
                        words = words + item
                    
                    if words not in Words_Dict.keys():
                        Words_Dict.update({words: 1})
                    else:
                        Words_Dict[words] = Words_Dict[words] + 1
                
                    Words_Processing_Fac = []
                    
    # print(Words_Dict)
    # print('There are', len(Words_Dict), 'word in this paragraph.')
    
    return Words_Dict

contents = multi_open('docs')
Word_Dict = Count_Word_from_List(contents)
# Word_Dict_1 = list(Count_Word_from_List(contents))
# # print(list(Word_Dict_1))
# # MAX_FIVE = {}
# # print(Word_Dict)
# n = 0
# while n <= 5:
#     for item in Word_Dict_1.items():
#         if (Word_Dict[item] == max(Word_Dict.values())):
#             # MAX_FIVE.update{key: value}
#             print(item, Word_Dict[item])
#             n += 1
#             del Word_Dict_1[key]
SORT = zip(Word_Dict.values(), Word_Dict.keys())

LIST = sorted(SORT, reverse=True)
# print(LIST)
print('The top 5 most frequent words are:')
for i in range(5):
    print(LIST[i][1])
    
            

            
        
    


